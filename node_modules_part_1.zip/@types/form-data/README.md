# Installation
> `npm install --save @types/form-data`

# Summary
This package contains type definitions for form-data (https://github.com/felixge/node-form-data).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/form-data

Additional Details
 * Last updated: Tue, 22 Nov 2016 23:38:10 GMT
 * File structure: ProperModule
 * Library Dependencies: node
 * Module Dependencies: stream
 * Global values: FormData

# Credits
These definitions were written by Carlos Ballesteros Velasco <https://github.com/soywiz>, Leon Yu <https://github.com/leonyu>.
