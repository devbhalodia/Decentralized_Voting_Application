# Installation
> `npm install --save @types/bn.js`

# Summary
This package contains type definitions for bn.js (https://github.com/indutny/bn.js).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bn.js.

### Additional Details
 * Last updated: Sat, 16 Jan 2021 18:04:06 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Leonid Logvinov](https://github.com/LogvinovLeon), [Henry Nguyen](https://github.com/HenryNguyen5), and [Gaylor Bosson](https://github.com/Gilthoniel).
