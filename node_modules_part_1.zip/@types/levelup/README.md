# Installation
> `npm install --save @types/levelup`

# Summary
This package contains type definitions for levelup (https://github.com/Level/levelup).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/levelup.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 22:02:40 GMT
 * Dependencies: [@types/abstract-leveldown](https://npmjs.com/package/@types/abstract-leveldown), [@types/level-errors](https://npmjs.com/package/@types/level-errors), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Meirion Hughes](https://github.com/MeirionHughes), [Daniel Byrne](https://github.com/danwbyrne), and [Carson Farmer](https://github.com/carsonfarmer).
