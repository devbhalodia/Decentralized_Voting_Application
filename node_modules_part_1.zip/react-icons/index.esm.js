// THIS FILE IS AUTO GENERATED
import * as m from './lib/esm/index.js'
export default m
    