'use strict';

module.exports = require('./server.node');
