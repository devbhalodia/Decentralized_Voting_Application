import { Parser } from '.';

declare const parser: {
    parsers: {
        espree: Parser;
    };
};
export = parser;
